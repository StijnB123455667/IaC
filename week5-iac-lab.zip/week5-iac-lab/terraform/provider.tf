provider "azurerm" {
  features {}
}
